	<div>
		<a href="tel:+84938717780"> <div class="fixed-btn2">
			<img width="60px" height="60px" src="/images/phone.png">
			<div class="image__overlay image__overlay--primary">
				<p class="image__description">
					Call<br>us
				</p>
			</div>
			</div>
		</a>
	</div> 
	<div>
		<a href="https://zalo.me/84938717780?fbclid=IwAR0oFOsdNlxxSskr6TdIgtszdkg5AM1Kty4jEAJeuWS684GSQzQYw-bIYlk">
			<div class="fixed-btn">
				<p>zalo</p>
			</div>
		</a>
	</div>